import pytest
from unittest.mock import patch
from io import StringIO
import sys
import math

# Import the functions from the main code
from your_main_code import calculate_rectangle, calculate_square, calculate_triangle

# Define tests for each function

def test_calculate_rectangle():
    assert calculate_rectangle(4, 5) == (20, 18)
    assert calculate_rectangle(1.5, 3.5) == (5.25, 10)

def test_calculate_square():
    assert calculate_square(3) == (9, 12)
    assert calculate_square(2.5) == (6.25, 10)

def test_calculate_triangle():
    assert math.isclose(calculate_triangle(4, 5), (10.0, None), rel_tol=1e-9)
    assert math.isclose(calculate_triangle(2.5, 3.5), (4.375, None), rel_tol=1e-9)

# Mock user input for testing the main menu choices

def mock_user_input(mocked_inputs):
    return lambda _: mocked_inputs.pop(0)

def test_main_menu_rectangle():
    with patch('builtins.input', mock_user_input(['1', '4'])):
        captured_output = StringIO()
        sys.stdout = captured_output
        your_main_code.main()
        sys.stdout = sys.__stdout__  # Reset sys.stdout to its normal state
        output = captured_output.getvalue()
        assert "The area of the rectangle is 20.0" in output
        assert "The perimeter of the rectangle is 18.0" in output

# Similarly, you can write tests for the square and triangle options.

# Run the tests

if __name__ == '__main__':
    pytest.main()
